package com.example.qm.pirobot;

import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.IOException;

public class Registe extends AppCompatActivity
{
    private static final String TAG = "Registe";
    public String userName;
    public String passWord;
    Message toServerMsg;
    ContentInfo contentInfo;
    ClientThread clientThread;
    Handler registeHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registe);
        //获得相应的按钮
        Button regBnt=(Button)findViewById(R.id.bReg);
        Button backBnt=(Button)findViewById(R.id.bBack);

        registeHandler=new Handler()
        {
            public void handleMessage(Message msg)
            {
                Log.d(TAG, "REGISTE 收到 服务器消息:"+new String((byte[])msg.obj));
                if(msg.what==0x11111)
                {
                    Toast.makeText(Registe.this, "SERVER DOWN", Toast.LENGTH_SHORT).show();
                    finish();
                }
                else if(msg.what==0x10000)
                    if(new String((byte[])msg.obj).compareTo("0100")==0)
                    {
                        Toast.makeText(Registe.this, "注册成功", Toast.LENGTH_SHORT).show();
                        Intent intent=new Intent(Registe.this,Control.class);
                        intent.putExtra("eUsername",userName);
                        intent.putExtra("ePassword",passWord);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        try {
                            clientThread.socketLinkedToAppServer.close();
                        } catch (IOException e) {
                            Log.d(TAG,"关闭服务器端口失败!");
                        }
                        finish();
                        startActivity(intent);
                    }
                    else if(new String((byte[])msg.obj).compareTo("0101")==0)
                        Toast.makeText(Registe.this, "注册失败", Toast.LENGTH_SHORT).show();
                    else if(new String((byte[])msg.obj).compareTo("0000")==0)
                    {
                        Toast.makeText(Registe.this, "服务器Down，请稍后重新启动APP", Toast.LENGTH_SHORT).show();
                        try {
                            clientThread.socketLinkedToAppServer.close();
                        } catch (IOException e) {
                            Log.d(TAG,"关闭服务器端口失败!");
                        }
                        //将activity关闭
                        finish();
                    }
                    else if(new String((byte[])msg.obj).compareTo("0111")==0)
                    {
                        Toast.makeText(Registe.this, "APP发送消息格式不正确，请重新发送", Toast.LENGTH_SHORT).show();
                    }
                    else if(new String((byte[])msg.obj).compareTo("1000")==0)
                    {
                        Toast.makeText(Registe.this, "session连接异常，请稍后重新启动APP", Toast.LENGTH_SHORT).show();
                        try {
                            clientThread.socketLinkedToAppServer.close();
                        } catch (IOException e) {
                            Log.d(TAG,"关闭服务器端口失败!");
                        }
                        finish();
                    }
                    else if(new String((byte[])msg.obj).compareTo("1001")==0)
                    {
                        Toast.makeText(Registe.this, "已有用户登录请,稍后登录!", Toast.LENGTH_SHORT).show();
                    }
                Log.d(TAG, "切换到 ClientThread 中");
            }
        };
        //初始化ClientThread
        clientThread=new ClientThread(registeHandler);
        new Thread(clientThread).start();

        regBnt.setOnClickListener(new View.OnClickListener()
                                  {
                                      @Override
                                      public void onClick(View v)
                                      {
                                          EditText t1=(EditText)findViewById(R.id.uusername);
                                          userName=t1.getText().toString();
                                          EditText t2=(EditText)findViewById(R.id.ppassword);
                                          passWord=t2.getText().toString();
                                          int size1=userName.length();
                                          int size2=passWord.length();
                                          //用户名、密码不能为空
                                          if(size1 < 1 || size1 >50 || size2<1 || size2>50)
                                              Toast.makeText(Registe.this, "请按照规范的用户名、密码格式进行填写！", Toast.LENGTH_SHORT).show();
                                          else
                                          {
                                              //向服务器发送信息
                                              contentInfo=new ContentInfo();
                                              contentInfo.init(userName,passWord);
                                              //设置为注册模式
                                              contentInfo.setMode("0100");
                                              toServerMsg=new Message();
                                              toServerMsg.what=0x10100;
                                              toServerMsg.obj=new String(contentInfo.getContentBytes());
                                              Log.d(TAG, "Registe 向服务器 发送的消息:"+contentInfo.getContentString());
                                              clientThread.sendToServerHandler.sendMessage(toServerMsg);
                                          }
                                      }
                                  }
        );

        backBnt.setOnClickListener(new View.OnClickListener()
                                   {
                                       @Override
                                       public void onClick(View v)
                                       {
                                           Intent intent = new Intent(Registe.this, Login.class);
                                           intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                           try {
                                               clientThread.socketLinkedToAppServer.close();
                                           } catch (IOException e) {
                                               Log.d(TAG,"关闭服务器端口失败!");
                                           }
                                           finish();
                                           startActivity(intent);
                                           overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);
                                       }
                                   }
        );
    }
}

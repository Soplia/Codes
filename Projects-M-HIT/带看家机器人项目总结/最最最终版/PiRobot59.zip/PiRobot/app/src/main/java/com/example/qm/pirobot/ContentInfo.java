package com.example.qm.pirobot;

/**
 * Created by QM on 2017/12/4.
 */


import android.util.Log;

/**
 * Created by QM on 2017/4/28.
 * mode=0010 向CommandServer传送运动控制命令
 * mode=0111 向RPIServer传送停止运动命令
 * mode=0101 向RPIServer传送视频控制命令
 */

public class ContentInfo
{
    private static final String TAG="ContentInfo";

    private  boolean isVideoStart;

    //用户账号
    private String username ;

    //用户密码
    private String password;

    //请求类型
    private String mode;

    //前进
    private String front;

    //后退
    private String back;

    //左
    private String left;
    //右
    private String right;

    //抬头
    private String up;

    //低头
    private String down;

    //视频
    private String video;

    //停止
    private String stop;

    //返回所有内容的字符串
    public String getContentString()
    {
        if(isVideoStart)
            video="1";
        else
            video="0";
        String str="#";
        str+=username+"#";
        str+=password+"#";
        //使用一位数字，如 1
        str+=mode+"#";
        str+=front+"#";
        str+=back+"#";
        str+=left+"#";
        str+=right+"#";
        str+=up+"#";
        str+=down+"#";
        str+=video+"#";
        Log.d(TAG, str);
        return str;
    }

    public void init(String a,String b)
    {
        username=a;
        password=b;
        mode="0";
        front="0";
        back="0";
        left="0";
        right="0";
        up="0";
        down="0";
        video="0";
    }
    //将控制信息清零
    public void clear()
    {
        front="0";
        back="0";
        left="0";
        right="0";
        up="0";
        down="0";
        video="0";
    }
    //返回要传送内容的二进制数组
    public byte[] getContentBytes()
    {
        return getContentString().getBytes();
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    public String getFront() {
        return front;
    }

    public void setFront(String front) {
        this.front = front;
    }

    public String getBack() {
        return back;
    }

    public void setBack(String back) {
        this.back = back;
    }

    public String getLeft() {
        return left;
    }

    public void setLeft(String left) {
        this.left = left;
    }

    public String getRight() {
        return right;
    }

    public void setRight(String right) {
        this.right = right;
    }

    public String getUp() {
        return up;
    }

    public void setUp(String up) {
        this.up = up;
    }

    public String getDown() {
        return down;
    }

    public void setDown(String down) {
        this.down = down;
    }

    public String getVideo() {
        return video;
    }

    public void setVideo(String video) {
        this.video = video;
    }

    public boolean isVideoStart() {
        return isVideoStart;
    }

    public void setVideoStart(boolean videoStart) {
        isVideoStart = videoStart;
    }

}



package com.example.qm.pirobot;


import java.io.IOException;
import java.text.SimpleDateFormat;

import android.app.Application;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Date;
import java.util.Queue;
import java.util.LinkedList;
import java.util.Stack;
import java.util.Timer;
import java.util.TimerTask;

///  MODE
/// 0000    APP DOWN
/// 0001    APP UP
/// 0010    APP CONTROL
/// 0011    APP LOGIN
/// 0100    APP REGISTE

public class Control extends AppCompatActivity implements  Runnable {
    private static final String TAG = "Text";

    ContentInfo contentInfo;
    Intent intent;
    ClientThread clientThread;
    Handler controlHandler;

    //声明各种组件
    Button frontButton;
    Button backButton;
    Button leftButton;
    Button rightButton;
    Button upButton;
    Button downButton;
    Button videoButton;
    TextView textViewLeft;
    TextView textViewRight;
    TextView textViewNetSpeed;
    TextView tv_front;
    TextView tv_back;
    TextView tv_left;
    TextView tv_right;

    //进行图片绘制的各种参数的声明
    SurfaceView cSurface;
    private SurfaceHolder cHolder;
    private Canvas cCanvas;
    Bitmap cBmp;
    //surfaceview的长宽
    private int wOfSur;
    private int hOfSur;

    Stack<String> stackForPicName;

    //用于显示网速
    NetWorkSpeedUtils networkSpeedUtils;
    //用于将图片旋转180°
    Matrix matrix;
    //测距信息
    String[] disArr;
    //用于显示网速的toast
    Toast toast;
    //标志视频状态
    boolean videoSta;

    //标志是否发生绘画异常
    boolean isDrawExceptionHappen;

    //调试成功后删除
    Date curDate;
    Date finDate;

    boolean isBntPress[];
    int totalNumOfButton;
    //是否从服务器收到绘制图片的命令
    boolean getMessageFromServer;
    //是否将要终止线程的运行
    boolean isSurfaceLive;

    //初始化contentInfo并且获得各个组件实例
    public void init() {
        Log.d(TAG, "CONTROL 正在进行初始化....");

        matrix = new Matrix();
        matrix.postRotate(180); /*翻转180度*/

        curDate = null;
        finDate = null;

        videoSta = false;
        totalNumOfButton = 6;
        isBntPress = new boolean[totalNumOfButton];
        for (int i = 0; i < totalNumOfButton; i++)
            isBntPress[i] = false;

        frontButton = (Button) findViewById(R.id.btnForward);
        backButton = (Button) findViewById(R.id.btnBackward);
        leftButton = (Button) findViewById(R.id.btnTurnLeft);
        rightButton = (Button) findViewById(R.id.btnTurnRight);
        upButton = (Button) findViewById(R.id.bntHeadUp);
        downButton = (Button) findViewById(R.id.bntHeadDown);
        videoButton = (Button) findViewById(R.id.btnVideo);
        //textViewLeft = (TextView) findViewById(R.id.textViewLeft);
        //textViewRight = (TextView) findViewById(R.id.textViewRight);
        textViewNetSpeed = (TextView) findViewById(R.id.textViewNetSpeed);

        tv_front = (TextView) findViewById(R.id.tv_front);
        tv_back = (TextView) findViewById(R.id.tv_back);
        tv_left = (TextView) findViewById(R.id.tv_left);
        tv_right = (TextView) findViewById(R.id.tv_right);

        intent = getIntent();
        contentInfo = new ContentInfo();
        contentInfo.init(intent.getStringExtra("eUsername"), intent.getStringExtra("ePassword"));

        contentInfo.setMode("0010");

        cSurface = (SurfaceView) findViewById(R.id.surface);
        cSurface.setKeepScreenOn(true);
        cHolder = cSurface.getHolder();

        //栈与队列有不同的地方
        stackForPicName = new Stack<String>();
        stackForPicName.clear();

        Log.d(TAG, "进入Init中，初始化完成！");
    }

    // 为各个按钮设置监听器
    public void setListener() {
        //前进，点击一次前进一下
        /*
        frontButton.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        //Log.d(TAG, "开始向服务器发送信息...");
                        contentInfo.clear();
                        contentInfo.setFront("1");
                        contentInfo.setVideoStart(videoSta);
                        Message msg=new Message();
                        msg.what=0x10100;
                        msg.obj=new String(contentInfo.getContentBytes());
                        //Log.d(TAG, "onClick: 信息构造完成！");
                        clientThread.sendToServerHandler.sendMessage(msg);
                        ///Log.d(TAG, "onClick: 向服务器发送信息执行结束!");
                    }
                }
        );
        */
        frontButton.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                //抬起操作
                if (motionEvent.getAction() == MotionEvent.ACTION_UP) {
                    new Thread(
                            new Runnable() {
                                @Override
                                public void run() {
                                    //全零代表停止
                                    contentInfo.clear();
                                    contentInfo.setMode("0111");
                                    Message msg = new Message();
                                    msg.what = 0x10100;
                                    msg.obj = new String(contentInfo.getContentBytes());
                                    contentInfo.setMode("0010");
                                    clientThread.sendToServerHandler.sendMessage(msg);
                                }
                            }
                    ).start();
                    Log.d(TAG, "前进按钮抬起来了");
                }
                //按下操作
                if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
                    new Thread(
                            new Runnable() {
                                @Override
                                public void run() {
                                    //在这里添加函数
                                    contentInfo.clear();
                                    contentInfo.setFront("1");

                                    Message msg = new Message();
                                    msg.what = 0x10100;
                                    msg.obj = new String(contentInfo.getContentBytes());

                                    clientThread.sendToServerHandler.sendMessage(msg);
                                }
                            }
                    ).start();
                    Log.d(TAG, "前进按钮按下了");
                }
                return false;
            }
        });

        //后退，按一次后退一次
/*
        backButton.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //Log.d(TAG, "onClick: 开始向服务器发送信息...");
                        contentInfo.clear();
                        contentInfo.setBack("1");
                        contentInfo.setVideoStart(videoSta);
                        Message msg=new Message();
                        msg.what=0x10100;
                        msg.obj=new String(contentInfo.getContentBytes());
                        //Log.d(TAG, "onClick: 信息构造完成！");
                        clientThread.sendToServerHandler.sendMessage(msg);
                        //Log.d(TAG, "onClick: 向服务器发送信息执行结束!");
                    }
                }
        );
*/

        backButton.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                //抬起操作
                if (motionEvent.getAction() == MotionEvent.ACTION_UP) {
                    new Thread(
                            new Runnable() {
                                @Override
                                public void run() {
                                    //在这里添加函数
                                    contentInfo.clear();
                                    contentInfo.setMode("0111");
                                    Message msg = new Message();
                                    msg.what = 0x10100;
                                    msg.obj = new String(contentInfo.getContentBytes());
                                    contentInfo.setMode("0010");
                                    clientThread.sendToServerHandler.sendMessage(msg);
                                }
                            }
                    ).start();
                    Log.d(TAG, "后退按钮抬起来了");
                }
                //按下操作
                if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
                    new Thread(
                            new Runnable() {
                                @Override
                                public void run() {
                                    //在这里添加函数
                                    contentInfo.clear();
                                    contentInfo.setBack("1");
                                    Message msg = new Message();
                                    msg.what = 0x10100;
                                    msg.obj = new String(contentInfo.getContentBytes());
                                    clientThread.sendToServerHandler.sendMessage(msg);
                                }
                            }
                    ).start();
                    Log.d(TAG, "后退按钮按下了");
                }
                return false;
            }
        });

        //向左
/*
        leftButton.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //Log.d(TAG, "onClick: 开始向服务器发送信息...");
                        contentInfo.clear();
                        contentInfo.setLeft("1");
                        contentInfo.setVideoStart(videoSta);
                        Message msg=new Message();
                        msg.what=0x10100;
                        msg.obj=new String(contentInfo.getContentBytes());
                        //Log.d(TAG, "onClick: 信息构造完成！");
                        clientThread.sendToServerHandler.sendMessage(msg);
                        //Log.d(TAG, "onClick: 向服务器发送信息执行结束!");
                    }
                }
        );
        */
        leftButton.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                //抬起操作
                if (motionEvent.getAction() == MotionEvent.ACTION_UP) {
                    new Thread(
                            new Runnable() {
                                @Override
                                public void run() {
                                    contentInfo.clear();
                                    contentInfo.setMode("0111");
                                    Message msg = new Message();
                                    msg.what = 0x10100;
                                    msg.obj = new String(contentInfo.getContentBytes());
                                    contentInfo.setMode("0010");
                                    clientThread.sendToServerHandler.sendMessage(msg);
                                }
                            }
                    ).start();
                    Log.d(TAG, "左转按钮抬起来了");
                }
                //按下操作
                if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
                    new Thread(
                            new Runnable() {
                                @Override
                                public void run() {
                                    //在这里添加函数
                                    contentInfo.clear();
                                    contentInfo.setLeft("1");
                                    Message msg = new Message();
                                    msg.what = 0x10100;
                                    msg.obj = new String(contentInfo.getContentBytes());
                                    clientThread.sendToServerHandler.sendMessage(msg);
                                }
                            }
                    ).start();
                    Log.d(TAG, "左转按钮按下了");
                }
                return false;
            }
        });
        //向右
/*
        rightButton.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //Log.d(TAG, "onClick: 开始向服务器发送信息...");
                        contentInfo.clear();
                        contentInfo.setRight("1");
                        contentInfo.setVideoStart(videoSta);
                        Message msg=new Message();
                        msg.what=0x10100;
                        msg.obj=new String(contentInfo.getContentBytes());
                        //Log.d(TAG, "onClick: 信息构造完成！");
                        clientThread.sendToServerHandler.sendMessage(msg);
                        //Log.d(TAG, "onClick: 向服务器发送信息执行结束!");
                    }
                }
        );
       */
        rightButton.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                //抬起操作
                if (motionEvent.getAction() == MotionEvent.ACTION_UP) {
                    new Thread(
                            new Runnable() {
                                @Override
                                public void run() {
                                    //在这里添加函数
                                    contentInfo.clear();
                                    contentInfo.setMode("0111");
                                    Message msg = new Message();
                                    msg.what = 0x10100;
                                    msg.obj = new String(contentInfo.getContentBytes());
                                    contentInfo.setMode("0010");
                                    clientThread.sendToServerHandler.sendMessage(msg);
                                }
                            }
                    ).start();
                    Log.d(TAG, "右转按钮抬起来了");
                }
                //抬起操作
                if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
                    new Thread(
                            new Runnable() {
                                @Override
                                public void run() {
                                    //在这里添加函数
                                    contentInfo.clear();
                                    contentInfo.setRight("1");
                                    Message msg = new Message();
                                    msg.what = 0x10100;
                                    msg.obj = new String(contentInfo.getContentBytes());
                                    clientThread.sendToServerHandler.sendMessage(msg);
                                }
                            }
                    ).start();
                    Log.d(TAG, "右转按钮按下了");
                }
                return false;
            }
        });
        //抬头
/*
        upButton.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //Log.d(TAG, "onClick: 开始向服务器发送信息...");
                        contentInfo.clear();
                        contentInfo.setUp("1");
                        contentInfo.setVideoStart(videoSta);
                        Message msg=new Message();
                        msg.what=0x10100;
                        msg.obj=new String(contentInfo.getContentBytes());
                        //Log.d(TAG, "onClick: 信息构造完成！");
                        clientThread.sendToServerHandler.sendMessage(msg);
                        //Log.d(TAG, "onClick: 向服务器发送信息执行结束!");
                    }
                }
        );
*/
        upButton.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                //抬起操作
                if (motionEvent.getAction() == MotionEvent.ACTION_UP) {
                    new Thread(
                            new Runnable() {
                                @Override
                                public void run() {
                                    //在这里添加函数
                                    contentInfo.clear();
                                    contentInfo.setMode("0111");
                                    Message msg = new Message();
                                    msg.what = 0x10100;
                                    msg.obj = new String(contentInfo.getContentBytes());
                                    contentInfo.setMode("0010");
                                    clientThread.sendToServerHandler.sendMessage(msg);
                                }
                            }
                    ).start();
                    Log.d(TAG, "抬摄像头按钮抬起来了");
                }
                //按下操作
                if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
                    new Thread(
                            new Runnable() {
                                @Override
                                public void run() {
                                    //在这里添加函数
                                    contentInfo.clear();
                                    contentInfo.setUp("1");
                                    Message msg = new Message();
                                    msg.what = 0x10100;
                                    msg.obj = new String(contentInfo.getContentBytes());
                                    clientThread.sendToServerHandler.sendMessage(msg);
                                }
                            }
                    ).start();
                    Log.d(TAG, "抬摄像头按钮按下了");
                }
                return false;
            }
        });

        //低头
/*
        downButton.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //Log.d(TAG, "onClick: 开始向服务器发送信息...");
                        contentInfo.clear();
                        contentInfo.setDown("1");
                        contentInfo.setVideoStart(videoSta);
                        Message msg=new Message();
                        msg.what=0x10100;
                        msg.obj=new String(contentInfo.getContentBytes());
                        //Log.d(TAG, "onClick: 信息构造完成！");
                        clientThread.sendToServerHandler.sendMessage(msg);
                        //Log.d(TAG, "onClick: 向服务器发送信息执行结束!");
                    }
                }
        );
       */
        downButton.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                //抬起操作
                if (motionEvent.getAction() == MotionEvent.ACTION_UP) {
                    new Thread(
                            new Runnable() {
                                @Override
                                public void run() {
                                    //在这里添加函数
                                    contentInfo.clear();
                                    contentInfo.setMode("0111");
                                    Message msg = new Message();
                                    msg.what = 0x10100;
                                    msg.obj = new String(contentInfo.getContentBytes());
                                    contentInfo.setMode("0010");
                                    clientThread.sendToServerHandler.sendMessage(msg);
                                }
                            }
                    ).start();
                    Log.d(TAG, "拉低摄像头按钮抬起来了");
                }
                //抬起操作
                if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
                    new Thread(
                            new Runnable() {
                                @Override
                                public void run() {
                                    //在这里添加函数
                                    contentInfo.clear();
                                    contentInfo.setDown("1");
                                    Message msg = new Message();
                                    msg.what = 0x10100;
                                    msg.obj = new String(contentInfo.getContentBytes());
                                    clientThread.sendToServerHandler.sendMessage(msg);
                                }
                            }
                    ).start();
                    Log.d(TAG, "拉低摄像头按钮按下了");
                }
                return false;
            }
        });

        //视频
        videoButton.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        contentInfo.clear();
                        videoSta = !videoSta;
                        contentInfo.setVideoStart(videoSta);
                        //为了将信息直接传送到6969端口，强制进行更改
                        contentInfo.setMode("0101");
                        Message msg = new Message();
                        msg.what = 0x10100;
                        msg.obj = new String(contentInfo.getContentBytes());
                        contentInfo.setMode("0010");
                        clientThread.sendToServerHandler.sendMessage(msg);
                    }
                }
        );

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_control);

        init();
        setListener();

        //为SurfaceView添加回调函数
        cHolder.addCallback(new SurfaceHolder.Callback() {
            public void surfaceDestroyed(SurfaceHolder holder) {
                isSurfaceLive = false;
            }

            public void surfaceCreated(SurfaceHolder holder) {
                isSurfaceLive = true;
                new Thread(Control.this).start();
            }

            //在切换到这个activity的时候就进行了创建
            public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
                wOfSur = width;
                hOfSur = height;
            }
        });

        controlHandler = new Handler() {
            public void handleMessage(Message msg) {
                //Log.d(TAG, "CONTROL 收到 服务器消息:"+new String((byte[])msg.obj));
                if (msg.what == 0x10010) {
                    //只要收到一次就将其设置为TRUE，允许APP进行画图
                    getMessageFromServer = true;
                    stackForPicName.push(new String((byte[]) msg.obj).substring(1));
                } else if (msg.what == 0x10011) {
                    //获得测距信息
                    disArr = (new String((byte[]) msg.obj).substring(1)).split(",");
                    //String temp = "F:" + disArr[0] + "B:" + disArr[2] + "L:" + disArr[3] + "R:" + disArr[1];
                    //Log.d(TAG,"收到的测距信息是:"+temp);

                    showDisMessage(disArr);
                    //这个地方已经分散开了，只是进行显示的问题了。

                    //textViewLeft.setText(temp);
                    // textViewRight.setText(temp);
                } else if (msg.what == 0x11111) {
                    //获得网速信息
                    textViewNetSpeed.setText("NetSpeed:" + (String) msg.obj + " kb/s");
                    //如果网速小于10kb,则显示网速较慢信息
                    if (((int) Double.parseDouble((String) msg.obj)) < 120) {
                        toast = Toast.makeText(Control.this, "网速较慢", Toast.LENGTH_LONG);
                        //让toast显示一秒的时间，为了能够快速的进行响应
                        showMyToast(toast, 1000);
                    }
                } else if (msg.what == 0x10000) {
                    if (new String((byte[]) msg.obj).compareTo("0000") == 0) {
                        Toast.makeText(Control.this, "服务器Down，请稍后重新启动APP", Toast.LENGTH_SHORT).show();
                        onControlStop();
                    } else if (new String((byte[]) msg.obj).compareTo("0111") == 0) {
                        Toast.makeText(Control.this, "APP发送消息格式不正确，请重新发送", Toast.LENGTH_SHORT).show();
                    } else if (new String((byte[]) msg.obj).compareTo("1010") == 0) {
                        Toast.makeText(Control.this, "服务器未启动，请稍后重试", Toast.LENGTH_SHORT).show();
                    } else if (new String((byte[]) msg.obj).compareTo("1000") == 0) {
                        Toast.makeText(Control.this, "session连接异常，请稍后重新启动APP", Toast.LENGTH_SHORT).show();
                        onControlStop();
                    }//AppDown
                    else if (new String((byte[]) msg.obj).compareTo("1000") == 0) {
                        Toast.makeText(Control.this, "session连接异常，请稍后重新启动APP", Toast.LENGTH_SHORT).show();
                        onControlStop();
                    }
                } else if (msg.what == 0x10001) {
                    Toast.makeText(Control.this, "服务器Down，请稍后重新启动APP", Toast.LENGTH_SHORT).show();
                    onControlStop();
                }
            }
        };

        clientThread = new ClientThread(controlHandler);
        new Thread(clientThread).start();

        //开启测试网速
        networkSpeedUtils = new NetWorkSpeedUtils(Control.this, controlHandler);
        networkSpeedUtils.startShowNetSpeed();

        //很重要
        new Thread(
                new Runnable() {
                    @Override
                    public void run() {
                        //这个要等osToserver创建之后再进行发送
                        while(true)
                            if(clientThread.osToServer!=null)
                            {
                                //全零代表停止
                                contentInfo.clear();
                                contentInfo.setMode("0001");
                                Message msg = new Message();
                                msg.what = 0x10100;
                                msg.obj = new String(contentInfo.getContentBytes());
                                clientThread.sendToServerHandler.sendMessage(msg);
                                contentInfo.setMode("0010");
                                Log.d(TAG,"App Up");
                                break;
                            }
                    }
                }
        ).start();

        Log.d(TAG, "向服务器发送Control创建命令");
    }

    //图片绘制部分
    public void run() {
        DrawPicFromIIS();
    }

    //正常使用
    private void DrawPicFromIIS() {
        while (isSurfaceLive) {
            if (getMessageFromServer) {
                synchronized (cHolder) {
                    if (!stackForPicName.empty()) {
                        cCanvas = cHolder.lockCanvas();
                        curDate = new Date(System.currentTimeMillis());//获取当前时间
                        HttpURLConnection conn = null;
                        String url = "http://59.110.142.250/image/" + stackForPicName.pop() + ".jpg";
                        Log.d(TAG, "Picurl:" + url);
                        URL videoUrl;//URL对象
                        try {
                            videoUrl = new URL(url);
                            conn = (HttpURLConnection) videoUrl.openConnection();//使用URL打开一个链接
                            InputStream iisInput = conn.getInputStream();
                            cBmp = BitmapFactory.decodeStream(iisInput);
                            //的确是旋转了180°，但是速度将下来了。大约多了200ms
                            Bitmap t = Bitmap.createBitmap(cBmp, 0, 0, cBmp.getWidth(), cBmp.getHeight(), matrix, true);
                            Date d1 = new Date(System.currentTimeMillis());
                            // Log.d(TAG,"获得图片时间差是"+(d1.getTime() - curDate.getTime())+"毫秒");
                            Rect fSrcRect = new Rect(0, 0, t.getWidth(), t.getHeight());
                            Rect sSrcRect = new Rect(0, 0, wOfSur, hOfSur);
                            cCanvas.drawBitmap(t, fSrcRect, sSrcRect, null);
                            finDate = new Date(System.currentTimeMillis());//获取当前时间
                            long diff = finDate.getTime() - curDate.getTime();
                            // Log.d(TAG,"绘图时间差是"+(finDate.getTime() - d1.getTime())+"毫秒");
                            //Log.d(TAG,"总时间差是"+(finDate.getTime() - curDate.getTime())+"毫秒");
                        } catch (Exception e) {
                            e.printStackTrace();
                            Log.d(TAG, "绘制图片出现错误！");
                        } finally {
                            conn.disconnect();
                            getMessageFromServer = false;
                            cHolder.unlockCanvasAndPost(cCanvas);
                        }
                    }

                }
            }//end if
        }//end While
    }

    //响应手机返回键.直接进行退出，即可。
    public void onBackPressed() {
        Log.d(TAG, "用户按下手机返回键！");
        (new android.app.AlertDialog.Builder(this)).setTitle("确认退出吗？").setPositiveButton("确定", new android.content.DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                Log.d(TAG, "用户确定退出！");
                //用户确定退出之后，需要向服务器发送消息，告知服务器，session已经退出
                //向服务器发送信息
                contentInfo.clear();
                //设置为注册模式
                contentInfo.setMode("0000");
                Message toServerMsg = new Message();
                toServerMsg.what = 0x10100;
                toServerMsg.obj = new String(contentInfo.getContentBytes());
                clientThread.sendToServerHandler.sendMessage(toServerMsg);
                Log.d(TAG, "向服务器发送APP DOWN消息");
                //先这样用着，等有机会再进行改正
                //应该是手机向APP发送APPDown消息之后，server回复给APP消息，然后APP再关闭线程并且推出。
                /*
                try {
                    clientThread.socketLinkedToAppServer.close();
                } catch (IOException e) {
                    Log.d(TAG, "关闭服务器端口失败!");
                }
                */
                networkSpeedUtils.stopTimer();
                finish();

                Log.d(TAG, "退出成功！");
            }
        }).setNegativeButton("返回", new android.content.DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
            }
        }).show();

    }

    //自定义Toast显示时间。cnt:需要显示的时长,毫秒。
    private void showMyToast(final Toast toast, final int cnt) {
        final Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                toast.show();
            }
        }, 0, 3000);//每隔三秒调用一次show方法;
        //注意这个地方是用Toast.LENGTH_LONG进行创建的

        new Timer().schedule(new TimerTask() {
            @Override
            public void run() {
                toast.cancel();
                timer.cancel();
            }
        }, cnt);//经过多长时间关闭该任务
    }

    public void onControlStop() {
        if (clientThread != null)
            clientThread.onLinkClosed();
        networkSpeedUtils.stopTimer();
        finish();
    }

    //显示测距信息
    public void showDisMessage(String[] arr) {
        String temp = "F:" + arr[0] + "B:" + arr[2] + "L:" + arr[3] + "R:" + arr[1];
        Log.d(TAG, "收到的测距信息是:" + temp);
        int f, b, l, r;
        f = b = l = r = 0;
        if (isDigit(arr[0]))
            f = Integer.parseInt(arr[0]);
        if (isDigit(arr[1]))
            b = Integer.parseInt(arr[1]);
        if (isDigit(arr[2]))
            r = Integer.parseInt(arr[2]);
        if (isDigit(arr[3]))
            l = Integer.parseInt(arr[3]);
        if (f < 40) {
            tv_front.setTextColor(Color.RED);
            tv_front.setText("FRONT:" + f);
            //Log.d(TAG,"f="+f);
        } else {
            tv_front.setTextColor(Color.BLACK);
            tv_front.setText("FRONT:" + f);
            //Log.d(TAG,"f="+f);
        }
        if (b < 40) {
            tv_back.setTextColor(Color.RED);
            tv_back.setText("BACK:" + b);
            //Log.d(TAG,"b="+b);
        } else {
            tv_back.setTextColor(Color.BLACK);
            tv_back.setText("BACK:" + b);
            //Log.d(TAG,"b="+b);
        }
        if (l < 40) {
            tv_left.setTextColor(Color.RED);
            tv_left.setText("LEFT:" + l);
            //Log.d(TAG,"l="+b);
        } else {
            tv_left.setTextColor(Color.BLACK);
            tv_left.setText("LEFT:" + l);
            //Log.d(TAG,"l="+b);
        }
        if (r < 40) {
            tv_right.setTextColor(Color.RED);
            tv_right.setText("RIGHT:" + r);
            //Log.d(TAG,"r="+b);
        } else {
            tv_right.setTextColor(Color.BLACK);
            tv_right.setText("RIGHT:" + r);
            //Log.d(TAG,"r="+b);
        }
    }

    // 判断一个字符串是否都为数字
    public boolean isDigit(String strNum) {
        return strNum.matches("[0-9]{1,}");
    }
/////*************************************/////
/////*************************************/////
/////*************************************/////

    //将数据流读入到byte数组中
    //正常使用
    private void DrawPicFromIISToArr() {
        //String temp=queueForPicName.poll();
        //直接从栈中弹出最新的图片
        String temp = stackForPicName.pop();
        String url = "http://101.200.41.248/image/" + temp + ".jpg";
        Log.d(TAG, "Picurl:" + url + "**");
        cCanvas = cHolder.lockCanvas();
        if (cCanvas != null) {
            try {
                curDate = new Date(System.currentTimeMillis());//获取当前时间
                URL videoUrl = new URL(url);//URL对象
                HttpURLConnection conn = (HttpURLConnection) videoUrl.openConnection();//使用URL打开一个链接
                Log.d(TAG, "成功打开连接!");
                //conn.setChunkedStreamingMode(1024);
                //允许输入流，即允许下载
                conn.setDoInput(true);
                //获取输入流，此时才真正建立链接
                InputStream iisInput = conn.getInputStream();
                Log.d(TAG, "成功获取到图片输入输出流！");
                cBmp = BitmapFactory.decodeStream(iisInput);
                //的确是旋转了180°，但是速度将下来了。大约多了200ms
                //Bitmap t=Bitmap.createBitmap(cBmp,0,0,cBmp.getWidth(),cBmp.getHeight(),matrix,true);
                Log.d(TAG, "成功将图片输入输出流解码!");
                Rect fSrcRect = new Rect(0, 0, cBmp.getWidth(), cBmp.getHeight());
                Rect sSrcRect = new Rect(0, 0, wOfSur, hOfSur);
                //利用画布的方法，经刚才初始化好的bitmap画到屏幕上。
                cCanvas.drawBitmap(cBmp, fSrcRect, sSrcRect, null);
                Log.d(TAG, "成功绘制图片");
                finDate = new Date(System.currentTimeMillis());//获取当前时间
                long diff = finDate.getTime() - curDate.getTime();
                //Toast.makeText(Control.this, "时间差是"+diff+"毫秒", Toast.LENGTH_SHORT).show();
                Log.d(TAG, "时间差是" + diff + "毫秒");
                //释放画布
                cHolder.unlockCanvasAndPost(cCanvas);
                conn.disconnect();
            } catch (Exception var4) {
                isDrawExceptionHappen = true;
                var4.printStackTrace();
            }
        } else {
            Log.d(TAG, "画布为空!");
        }
    }

    //获取图片的二进制信息
    public byte[] GetPictureData() {
        InputStream in = null;
        byte[] byteData = null;
        try {
            //获取到这张图片的ID编号
            in = getResources().openRawResource((Integer) R.drawable.class.getField("a123").get(null));
            //Log.d(TAG,"获取到图片文件");
            byteData = new byte[in.available()];
            in.read(byteData, 0, byteData.length);
            //Log.d(TAG,"123的二进制信息是:"+new String(byteData));
            //Log.d(TAG,"图片二进制数组大小："+byteData.length);
            //printPic1(byteData);
            //Log.d(TAG, "接收到的二进制信息16："+str2HexStr(new String(byteData)));
            in.close();
            //printPic(byteData);
            //Log.d(TAG,"图片二进制信息是"+ Arrays.toString(byteData));
        } catch (Exception e) {
            Log.d(TAG, "图片打开失败");
        }
        return byteData;
    }

    public void printPic1(byte bs[]) {
        char[] chars = "0123456789ABCDEF".toCharArray();
        StringBuilder sb = new StringBuilder("");
        int bit;
        for (int i = 0; i < bs.length; i++) {
            bit = (bs[i] & 0x0f0) >> 4;
            sb.append(chars[bit]);
            bit = bs[i] & 0x0f;
            sb.append(chars[bit]);
        }
        Log.d(TAG, "二进制数组是：" + sb.toString().trim());
        Log.d(TAG, "二进制数组长度：" + bs.length);
        //return sb.toString().trim();
    }

    //将十六进制字符串转化为byte数组
    public static byte[] hexStringToByte(String hexStr) {
        String str = "0123456789ABCDEF";
        char[] hexs = hexStr.toCharArray();
        byte[] bytes = new byte[hexStr.length() / 2];
        int n;

        for (int i = 0; i < bytes.length; i++) {
            n = str.indexOf(hexs[2 * i]) * 16;
            n += str.indexOf(hexs[2 * i + 1]);
            bytes[i] = (byte) (n & 0xff);
        }
        return bytes;
    }

}

package com.example.qm.pirobot;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

/**
 * Created by QM on 2017/10/23.
 ClientThread → Activity 通信格式
 /// ---------
 /// | 0-4   |
 /// ---------
 /// | #     |
 /// ---------
 /// 10000      正常反馈信息
 /// 10001      服务器 DOWN
 /// 10010      图片信息
 /// 10011      测距信息
 /// 10100      发送到服务器的信息
 */

public class ClientThread implements Runnable
{
    private static final String TAG = "SocketThread";
    public Socket socketLinkedToAppServer;
    Handler sendToActivityHandler;
    Handler sendToServerHandler;
    final static String IP="101.200.41.248";
    final static int PORT=6970;
    InputStream isFromServer;
    OutputStream osToServer;

    public ClientThread(Handler handler)
    {
        sendToActivityHandler=handler;
    }

    public void onLinkClosed()
    {
        if(isFromServer!=null)
            try {
                isFromServer.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        if(osToServer!=null)
            try {
                osToServer.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        if(socketLinkedToAppServer!=null)
            try {
                socketLinkedToAppServer.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
    }

    @Override
    public void run()
    {
        new Thread()
        {
            public void run()
            {
                try
                {
                    Log.d(TAG, "正在连接 SERVER...");
                    socketLinkedToAppServer = new Socket(IP, PORT);

                    Log.d(TAG, "成功连接 SERVER");
                    isFromServer = socketLinkedToAppServer.getInputStream();
                    osToServer = socketLinkedToAppServer.getOutputStream();
                    Log.d(TAG, "获取到 SERVER 输入输出流");
                    //循环 监听 服务器
                    while(true)
                    {
                        int count = 0;
                        while (count == 0)
                            count = isFromServer.available();
                        byte[] rebyte = new byte[count];
                        isFromServer.read(rebyte);
                        Message toActivityMsg = new Message();
                        //# 图片
                        if(rebyte[0]==0x23)
                        {
                            //Log.d(TAG,"收到测距信息");
                            toActivityMsg.what=0x10010;
                            //$ 测距信息
                        }
                        else if(rebyte[0]==0x24)
                            toActivityMsg.what=0x10011;
                            //反馈
                        else
                            toActivityMsg.what = 0x10000;
                        toActivityMsg.obj = rebyte;
                        sendToActivityHandler.sendMessage(toActivityMsg);
                        Log.d(TAG, "向 Activity 发送 "+ new String(rebyte)+" 信息完毕");
                    }
                }
                catch (Exception e)
                {
                    Log.d(TAG, "服务器Down.....");
                }
            }
        }.start();

        Looper.prepare();
        sendToServerHandler=new Handler()
        {
            public void handleMessage(Message msg)
            {
                try
                {
                    if(osToServer==null)
                        Log.d(TAG,"osToServer=null");
                    if(msg.what==0x10100)
                        osToServer.write(msg.obj.toString().getBytes());
                }
                catch (IOException e)
                {
                    e.printStackTrace();
                    Log.d(TAG, "发送信息时服务器Down.....");
                }
            }
        };
        Looper.loop();
    }
}
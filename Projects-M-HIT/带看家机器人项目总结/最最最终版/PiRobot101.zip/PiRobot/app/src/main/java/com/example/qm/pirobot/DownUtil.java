package com.example.qm.pirobot;

/**
 * Created by QM on 2017/12/4.
 */


import java.io.InputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.URL;

public class DownUtil
{
    public static final  String TAG="DownUtil";

    // 定义下载资源的路径
    private String path;
    // 指定要保存下载文件的byte数组
    private byte [] picArr;
    // 定义需要使用多少线程下载资源
    private int threadNum;
    // 定义下载的线程对象
    private DownThread[] threads;
    // 定义下载的文件的总大小
    private int fileSize;

    //构造函数
    public DownUtil(String path, int threadNum)
    {
        this.path = path;
        this.threadNum = threadNum;
        // 初始化threads数组
        threads = new DownThread[threadNum];
    }

    public void download() throws Exception
    {
        URL url = new URL(path);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        // 得到文件大小
        fileSize = conn.getContentLength();
        conn.disconnect();
        picArr=new byte[fileSize];
        int currentPartSize = fileSize / threadNum + 1;
        for (int i = 0; i < threadNum; i++)
        {
            // 计算每条线程的下载的开始位置
            int startPos = i * currentPartSize;
            // 创建下载线程
            threads[i] = new DownThread(startPos, currentPartSize,picArr);
            // 启动下载线程
            threads[i].start();
        }
    }


    // 获取下载的完成百分比
    public double getCompleteRate()
    {
        // 统计多条线程已经下载的总大小
        int sumSize = 0;
        for (int i = 0; i < threadNum; i++)
        {
            //这里很明显使用的自定义的线程
            sumSize += threads[i].length;
        }
        // 返回已经完成的百分比
        return sumSize * 1.0 / fileSize;
    }


    //这里是自定义的线程
    private class DownThread extends Thread
    {
        // 当前线程的下载位置
        private int startPos;
        // 定义当前线程负责下载的文件大小
        private int currentPartSize;
        // 当前线程需要下载的文件块
        private byte [] picArr;
        // 定义已经该线程已下载的字节数
        public int length;

        //构造函数
        public DownThread(int startPos, int currentPartSize,byte [] picArr)
        {
            this.startPos = startPos;
            this.currentPartSize = currentPartSize;
            this.picArr=picArr;
            //感觉这个地方应该进行初始化一下
            this.length=0;
        }

        @Override
        public void run()
        {
            try
            {
                URL url = new URL(path);
                HttpURLConnection conn = (HttpURLConnection)url
                        .openConnection();

                InputStream inStream = conn.getInputStream();
                // 跳过startPos个字节，表明该线程只下载自己负责的那部分文件
                skipFully(inStream, this.startPos);
//				inStream.skip(this.startPos);
                byte[] buffer = new byte[1024];
                int hasRead = 0;
                // 读取网络数据，并写入本地文件
                while (length < currentPartSize
                        && (hasRead = inStream.read(buffer)) > 0)
                {
                    //感觉这个地方有问题
                    inStream.read(buffer, 0, hasRead);
                    // 累计该线程下载的总大小
                    length += hasRead;
                }
                inStream.close();
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
        }
    }

    // 定义一个为InputStream跳过bytes字节的方法
    public static void skipFully(InputStream in, long bytes) throws IOException
    {
        long remainning = bytes;
        long len = 0;
        while (remainning > 0)
        {
            len = in.skip(remainning);
            remainning -= len;
        }
    }

}

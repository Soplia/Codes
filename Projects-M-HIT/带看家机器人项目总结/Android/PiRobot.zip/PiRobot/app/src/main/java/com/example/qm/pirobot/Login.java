package com.example.qm.pirobot;

import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.io.IOException;
import java.net.Socket;

public class Login extends AppCompatActivity
{
    private static final String TAG = "Login";
    public String userName;
    public String passWord;
    Message toServerMsg;
    ContentInfo contentInfo;
    ClientThread clientThread;
    Handler loginHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Button loginBnt=(Button)findViewById(R.id.bLogin);
        Button regBnt=(Button)findViewById(R.id.bRegister);

        Log.d(TAG,"进入 LOGIN 界面！");

        loginHandler=new Handler()
        {
            @Override
            public void handleMessage(Message msg)
            {
                //这边需要进行解决，还是有问题
                Log.d(TAG, "LOGIN 收到 服务器消息:"+new String((byte[])msg.obj));
                if(msg.what==0x10001)
                {
                    Toast.makeText(Login.this, "SERVER DOWN", Toast.LENGTH_SHORT).show();
                    try {
                        clientThread.socketLinkedToAppServer.close();
                    } catch (IOException e) {
                        Log.d(TAG,"关闭服务器端口失败!");
                    }
                    finish();
                }
                else if(msg.what==0x10000)
                    if(new String((byte[])msg.obj).compareTo("0010")==0)
                    {
                        Toast.makeText(Login.this, "登录成功", Toast.LENGTH_SHORT).show();
                        //进行页面切换
                        Intent intent=new Intent(Login.this,Control.class);
                        intent.putExtra("eUsername",userName);
                        intent.putExtra("ePassword",passWord);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        try {
                            clientThread.socketLinkedToAppServer.close();
                        } catch (IOException e) {
                            Log.d(TAG,"关闭服务器端口失败!");
                        }
                        finish();
                        startActivity(intent);
                    }
                    else if(new String((byte[])msg.obj).compareTo("0011")==0)
                        Toast.makeText(Login.this, "登录失败", Toast.LENGTH_SHORT).show();
                    else if (new String((byte[]) msg.obj).compareTo("1010") == 0)
                        Toast.makeText(Login.this, "服务器未启动，请稍后重试", Toast.LENGTH_SHORT).show();
                    else if(new String((byte[])msg.obj).compareTo("0000")==0)
                    {
                        Toast.makeText(Login.this, "服务器Down，请稍后重新启动APP", Toast.LENGTH_SHORT).show();
                        try {
                            clientThread.socketLinkedToAppServer.close();
                        } catch (IOException e) {
                            Log.d(TAG,"关闭服务器端口失败!");
                        }
                        //将activity关闭
                        finish();
                    }
                    else if(new String((byte[])msg.obj).compareTo("0111")==0)
                    {
                        Toast.makeText(Login.this, "APP发送消息格式不正确，请重新发送", Toast.LENGTH_SHORT).show();
                    }
                    else if(new String((byte[])msg.obj).compareTo("1000")==0)
                    {
                        Toast.makeText(Login.this, "session连接异常，请稍后重新启动APP", Toast.LENGTH_SHORT).show();
                        try {
                            clientThread.socketLinkedToAppServer.close();
                        } catch (IOException e) {
                            Log.d(TAG,"关闭服务器端口失败!");
                        }
                        //将activity关闭
                        finish();
                    }
                    else if(new String((byte[])msg.obj).compareTo("1001")==0)
                    {
                        Toast.makeText(Login.this, "已有用户登录请,稍后登录!", Toast.LENGTH_SHORT).show();
                    }
                Log.d(TAG, "切换到 ClientThread 中");
            }
        };

        loginBnt.setOnClickListener(new View.OnClickListener()
                                    {
                                        @Override
                                        public void onClick(View v)
                                        {
                                            EditText t1=(EditText)findViewById(R.id.username);
                                            userName=t1.getText().toString();
                                            EditText t2=(EditText)findViewById(R.id.password);
                                            passWord=t2.getText().toString();
                                            int size1=userName.length();
                                            int size2=passWord.length();
                                            //用户名 密码 不能够为空
                                            if(size1 < 1 || size1 >50 || size2<1 || size2>50)
                                                Toast.makeText(Login.this, "请规范填写用户名、密码！（1-50）", Toast.LENGTH_SHORT).show();
                                            else
                                            {
                                                //向服务器发送信息
                                                contentInfo=new ContentInfo();
                                                contentInfo.init(userName,passWord);
                                                //设置为登录模式
                                                contentInfo.setMode("0011");
                                                toServerMsg=new Message();
                                                toServerMsg.what=0x10100;
                                                toServerMsg.obj=new String(contentInfo.getContentBytes());
                                                Log.d(TAG, "Login 向服务器 发送的消息:"+contentInfo.getContentString());
                                                clientThread.sendToServerHandler.sendMessage(toServerMsg);
                                            }
                                        }
                                    }
        );

        regBnt.setOnClickListener(new View.OnClickListener()
                                  {
                                      @Override
                                      public void onClick(View v)
                                      {
                                          //跳转到注册页面
                                          Intent intent = new Intent(Login.this,Registe.class);
                                          intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                          try {
                                              clientThread.socketLinkedToAppServer.close();
                                          } catch (IOException e) {
                                              Log.d(TAG,"关闭服务器端口失败!");
                                          }
                                          finish();
                                          startActivity(intent);
                                      }
                                  }
        );

        clientThread=new ClientThread(loginHandler);
        new Thread(clientThread).start();

        isNetworkconnected();

        Log.d(TAG,"Login线程 创建 完毕");

    }

    //判断手机是否联网
    public void isNetworkconnected()
    {
        ConnectivityManager connectivityManager = (ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if(networkInfo == null || !networkInfo.isAvailable())
        {
            Toast.makeText(Login.this, "手机未连接网络，请设置", Toast.LENGTH_SHORT).show();
        }
        else
        {
            Toast.makeText(Login.this, "手机已经连接网络", Toast.LENGTH_SHORT).show();
        }
    }

}
